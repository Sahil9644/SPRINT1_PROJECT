package com.ars.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminDTO extends UserDTO {
	private String aName;
	private String email;

}
